#pragma once
 
#include "Runtime/UMG/Public/UMG.h"
#include "Runtime/UMG/Public/UMGStyle.h"
#include "TestSlate.h"
#include "TestWidget.generated.h"

UCLASS()
class UTestWidget : public UWidget
{
	GENERATED_BODY()

protected:
	TSharedPtr<STestSlate> _testSlate;

	virtual TSharedRef<SWidget> RebuildWidget() override;

	//FReply HandleMouseButtonDown(const FGeometry& Geometry, const FPointerEvent& MouseEvent);

public:
	/*UPROPERTY(EditDefaultsOnly, Category=Events)
	FOnPointerEvent OnMouseButtonDownEvent;*/

	UTestWidget(const FObjectInitializer& ObjectInitializer);

	virtual void SynchronizeProperties() override;
 
	virtual void ReleaseSlateResources(bool bReleaseChildren) override;

	UPROPERTY(EditAnywhere, Category = "Content")
	FText _text;

#if WITH_EDITOR

	virtual const FSlateBrush* GetEditorIcon() override;
	virtual const FText GetPaletteCategory() override;

#endif
 
};