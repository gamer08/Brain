#pragma once 

#include "SlateCore.h"
#include "STextBlock.h"

class STestSlate : public SCompoundWidget
{
public:

	SLATE_BEGIN_ARGS(STestSlate)
	{}
	SLATE_END_ARGS()

	void Construct(const FArguments& args);

	TSharedPtr<class STextBlock> _text;
};