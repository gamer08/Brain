#include "Brain.h"
#include "BrainSaveInterface.h"

UBrainSaveInterface::UBrainSaveInterface(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
}