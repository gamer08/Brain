// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Blueprint/UserWidget.h"
#include "BrainOptionsMenuWidget.generated.h"


USTRUCT(BlueprintType)
struct FInputIndex
{
	GENERATED_USTRUCT_BODY();

	FInputIndex()
	{}

	FInputIndex(FName name, int32 oldInputIndex, int32 newInputIndex)
	{
		_inputName = name;
		_oldInputIndex = oldInputIndex;
		_newInputIndex = newInputIndex;
	}

	UPROPERTY(BlueprintReadWrite, Category = "InputIdex")
	FName _inputName;
	
	UPROPERTY(BlueprintReadWrite, Category = "InputIdex")
	int32 _oldInputIndex;

	UPROPERTY(BlueprintReadWrite, Category = "InputIdex")
	int32 _newInputIndex;
};

UCLASS()
class BRAIN_API UBrainOptionsMenuWidget : public UUserWidget
{
	GENERATED_BODY()

private:
	
	UPROPERTY()
	TArray<FInputActionKeyMapping> _actions;

	UPROPERTY()
	TArray<FInputAxisKeyMapping> _axis;

	UPROPERTY()
	TMap<FName, FString> _inputKeyDisplayValues;

	void FillInputKeyDisplayValues();
	void FillCachedAxis(TArray<FKey>& keys);
	void FillCachedActions(TArray<FKey>& keys);

public:

	UPROPERTY(BlueprintReadWrite, Category = "Controls")
	TArray<FInputIndex> _axisSelectedKey;

	UPROPERTY(BlueprintReadWrite, Category = "Controls")
	TArray<FInputIndex> _actionsSelectedKey;
	
	UFUNCTION(BlueprintCallable, Category = "Controls")
	void FillControlsList(UScrollBox* container);	

	UFUNCTION(BlueprintCallable, Category = "Controls")
	void SaveControls();	
};
