#include "Brain.h"
#include "TestWidget.h"

//LOCTEXT
#define LOCTEXT_NAMESPACE "UMG"

UTestWidget::UTestWidget(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{
}

TSharedRef<SWidget> UTestWidget::RebuildWidget()
{
	_testSlate = SNew(STestSlate);
	return _testSlate.ToSharedRef();
}
 
void UTestWidget::SynchronizeProperties()
{
	Super::SynchronizeProperties();

	_testSlate->_text->SetText(_text);

}

void UTestWidget::ReleaseSlateResources(bool bReleaseChildren)
{
	Super::ReleaseSlateResources(bReleaseChildren);
 
	_testSlate.Reset();
}

//FReply UTestWidget::HandleMouseButtonDown(const FGeometry& Geometry, const FPointerEvent& MouseEvent)
//{
//	if ( OnMouseButtonDownEvent.IsBound() )
//	{
//		return OnMouseButtonDownEvent.Execute(Geometry, MouseEvent).NativeReply;
//	}
// 
//	return FReply::Unhandled();
//}
 
#if WITH_EDITOR
 
const FSlateBrush* UTestWidget::GetEditorIcon()
{
	return FUMGStyle::Get().GetBrush("Widget.Image");
}
 
const FText UTestWidget::GetPaletteCategory()
{
	return LOCTEXT("Common", "Common");
}
 
#endif

#undef LOCTEXT_NAMESPACE