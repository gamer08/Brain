#include "Brain.h"
#include "TestSlate.h"

void STestSlate::Construct(const FArguments& args)
{
	ChildSlot
		[
			SAssignNew(_text, STextBlock)
		];
}