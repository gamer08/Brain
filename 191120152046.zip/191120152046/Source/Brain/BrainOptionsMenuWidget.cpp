// Fill out your copyright notice in the Description page of Project Settings.

#include "Brain.h"
#include "BrainOptionsMenuWidget.h"
#include "BrainKeyComboBoxWidget.h"

void UBrainOptionsMenuWidget::FillControlsList(UScrollBox* container)
{	
	UInputSettings* settings = const_cast<UInputSettings*>(GetDefault<UInputSettings>());

	if (!settings)
		return;
	
	TArray<FKey> keys;
	EKeys::GetAllKeys(keys);
	
	FillInputKeyDisplayValues();
	FillCachedAxis(keys);
	FillCachedActions(keys);

	for (FInputAxisKeyMapping axis : _axis)
	{
		UHorizontalBox* line = NewObject<UHorizontalBox>(this);
		UTextBlock* actionName = NewObject<UTextBlock>(line);
		UBrainKeyComboBoxWidget* cb = NewObject<UBrainKeyComboBoxWidget>(line);

		actionName->Justification = ETextJustify::Center;
		actionName->SetText(FText::FromString(_inputKeyDisplayValues[axis.AxisName]));
		FSlateColor color = actionName->ColorAndOpacity.UseForeground();
		actionName->SetColorAndOpacity(color);
		
		for (FKey key : keys)
			cb->AddOption(key.GetDisplayName().ToString());

		cb->SetSelectedOption(axis.Key.GetDisplayName().ToString());

		line->AddChild(actionName);
		line->AddChild(cb);

		UHorizontalBoxSlot* slot = Cast<UHorizontalBoxSlot>(line->GetChildAt(0)->Slot);
		if (slot)
		{
			slot->SetPadding(FMargin(0.f, 0.f, 15.f, 0.f));
			
			FSlateChildSize slotSize = FSlateChildSize();
			slotSize.SizeRule = ESlateSizeRule::Fill;
			slotSize.Value = 0.2;
			slot->SetSize(slotSize);
		}

		UHorizontalBoxSlot* slot2 = Cast<UHorizontalBoxSlot>(line->GetChildAt(1)->Slot);
		if (slot2)
		{	
			FSlateChildSize slotSize = FSlateChildSize();
			slotSize.SizeRule = ESlateSizeRule::Fill;
			slotSize.Value = 0.1;
			slot2->SetSize(slotSize);
		}

		container->AddChild(line);
	}
		
	for (FInputActionKeyMapping action : _actions)
	{
		UHorizontalBox* line = NewObject<UHorizontalBox>(this);
		UTextBlock* actionName = NewObject<UTextBlock>(line);
		UBrainKeyComboBoxWidget* cb = NewObject<UBrainKeyComboBoxWidget>(line);

		actionName->Justification = ETextJustify::Center;
		actionName->SetText(FText::FromString(_inputKeyDisplayValues[action.ActionName]));
		FSlateColor color = actionName->ColorAndOpacity.UseForeground();
		actionName->SetColorAndOpacity(color);
		
		for (FKey key : keys)
			cb->AddOption(key.GetDisplayName().ToString());

		cb->SetSelectedOption(action.Key.GetDisplayName().ToString());

		line->AddChild(actionName);
		line->AddChild(cb);

		UHorizontalBoxSlot* slot = Cast<UHorizontalBoxSlot>(line->GetChildAt(0)->Slot);
		if (slot)
		{
			slot->SetPadding(FMargin(0.f, 0.f, 15.f, 0.f));
			
			FSlateChildSize slotSize = FSlateChildSize();
			slotSize.SizeRule = ESlateSizeRule::Fill;
			slotSize.Value = 0.2;
			slot->SetSize(slotSize);
		}

		UHorizontalBoxSlot* slot2 = Cast<UHorizontalBoxSlot>(line->GetChildAt(1)->Slot);
		if (slot2)
		{	
			FSlateChildSize slotSize = FSlateChildSize();
			slotSize.SizeRule = ESlateSizeRule::Fill;
			slotSize.Value = 0.1;
			slot2->SetSize(slotSize);
		}

		container->AddChild(line);
	}
}

void UBrainOptionsMenuWidget::SaveControls()
{
	UInputSettings* settings = const_cast<UInputSettings*>(GetDefault<UInputSettings>());
	
	if (!settings)
		return;

	TArray<FKey> keys;
	EKeys::GetAllKeys(keys);

	for (auto it(_axisSelectedKey.CreateIterator()); it; it++)
	{
		//si l'input � chang� on l'update
		if (it->_oldInputIndex != it->_newInputIndex)
		{
			settings->RemoveAxisMapping(_axis[it.GetIndex()]);
			const FInputAxisKeyMapping n(_axis[it.GetIndex()].AxisName, keys[it->_newInputIndex],_axis[it.GetIndex()].Scale);
			settings->AddAxisMapping(n);
		}
	}

	for (auto it(_actionsSelectedKey.CreateIterator()); it; it++)
	{
		//si l'input � chang� on l'update
		if (it->_oldInputIndex != it->_newInputIndex)
		{
			settings->RemoveActionMapping(_actions[it.GetIndex()]);
			const FInputActionKeyMapping n(_actions[it.GetIndex()].ActionName, keys[it->_newInputIndex]);
			settings->AddActionMapping(n);
		}
	}

	settings->SaveKeyMappings();

	for (TObjectIterator<UPlayerInput> it; it; ++it)
		it->ForceRebuildingKeyMaps(true);
}

void UBrainOptionsMenuWidget::FillCachedAxis(TArray<FKey>& keys)
{
	UInputSettings* settings = const_cast<UInputSettings*>(GetDefault<UInputSettings>());

	_axis.Add(*settings->AxisMappings.FindByPredicate([](FInputAxisKeyMapping axis){return axis.AxisName.IsEqual(FName("MoveForward")); }));
	_axis.Add(*settings->AxisMappings.FindByPredicate([](FInputAxisKeyMapping axis){return axis.AxisName.IsEqual(FName("MoveBackward")); }));
	_axis.Add(*settings->AxisMappings.FindByPredicate([](FInputAxisKeyMapping axis){return axis.AxisName.IsEqual(FName("MoveRight")); }));
	_axis.Add(*settings->AxisMappings.FindByPredicate([](FInputAxisKeyMapping axis){return axis.AxisName.IsEqual(FName("MoveLeft")); }));

	for (FInputAxisKeyMapping axis : _axis)
		_axisSelectedKey.Add(FInputIndex(axis.AxisName,keys.IndexOfByKey(axis.Key),0));
}

void UBrainOptionsMenuWidget::FillCachedActions(TArray<FKey>& keys)
{
	UInputSettings* settings = const_cast<UInputSettings*>(GetDefault<UInputSettings>());

	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("Jump")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject1")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject2")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject3")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject4")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject5")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject6")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject7")); }));
	_actions.Add(*settings->ActionMappings.FindByPredicate([](FInputActionKeyMapping action){return action.ActionName.IsEqual(FName("PerformActionOnObject8")); }));

	for (FInputActionKeyMapping action : _actions)
		_actionsSelectedKey.Add(FInputIndex(action.ActionName,keys.IndexOfByKey(action.Key),0));
}

void UBrainOptionsMenuWidget::FillInputKeyDisplayValues()
{
	_inputKeyDisplayValues.Emplace("Jump", "Sauter");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject1", "Rotation positive / Accelerer");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject2", "Rotation negative / Ralentir");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject3", "Translation Positive / Arreter");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject4", "Translation negative / Inverser");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject5", "Mise a l'echelle positive");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject6", "Mise a l'echelle negative");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject7", "Cisaillement positif");
	_inputKeyDisplayValues.Emplace("PerformActionOnObject8", "Cisaillement negatif");
	_inputKeyDisplayValues.Emplace("MoveForward", "Deplacement en avant");
	_inputKeyDisplayValues.Emplace("MoveBackward", "Deplacement en arriere");
	_inputKeyDisplayValues.Emplace("MoveLeft", "Deplacement sur la gauche");
	_inputKeyDisplayValues.Emplace("MoveRight", "Deplacement sur la droite");
}

